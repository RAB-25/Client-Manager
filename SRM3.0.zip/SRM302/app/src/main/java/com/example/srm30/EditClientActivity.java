package com.example.srm30;

import android.net.Uri;
import android.widget.ImageView;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.ImageView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class EditClientActivity extends AppCompatActivity {

    private FirebaseFirestore db;

    private String clientId;
    private FirebaseStorage storage;

    private Uri selectedImageUri;

    private String currentPhotoUrl = "";

    private EditText nameInput;
    private EditText emailInput;
    private EditText phoneInput;
    private EditText countryInput;
    private EditText companyInput;

    private ImageView photoView;
    private Uri selectedPhotoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_edit_client);

        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        // Get client ID
        clientId =
                getIntent().getStringExtra("clientId");

        initializeViews();

        loadClient();

        setupButtons();
    }


    // ==========================================
    // INITIALIZE VIEWS
    // ==========================================

    private void initializeViews() {

        nameInput =
                findViewById(R.id.editClientName);

        emailInput =
                findViewById(R.id.editClientEmail);

        phoneInput =
                findViewById(R.id.editClientPhone);

        countryInput =
                findViewById(R.id.editClientCountry);

        companyInput =
                findViewById(R.id.editClientCompany);

        photoView =
                findViewById(R.id.editClientPhoto);
    }


    // ==========================================
    // LOAD CLIENT
    // ==========================================

    private void loadClient() {

        if (clientId == null ||
                clientId.trim().isEmpty()) {

            Toast.makeText(
                    this,
                    "Client ID missing",
                    Toast.LENGTH_LONG
            ).show();

            finish();

            return;
        }


        db.collection("clients")
                .document(clientId)
                .get()

                .addOnSuccessListener(document -> {

                    if (!document.exists()) {

                        Toast.makeText(
                                this,
                                "Client not found",
                                Toast.LENGTH_LONG
                        ).show();

                        finish();

                        return;
                    }


                    nameInput.setText(
                            document.getString("name")
                    );

                    emailInput.setText(
                            document.getString("email")
                    );

                    phoneInput.setText(
                            document.getString("phone")
                    );

                    countryInput.setText(
                            document.getString("country")
                    );

                    companyInput.setText(
                            document.getString("company")
                    );
                })

                .addOnFailureListener(e -> {

                    Toast.makeText(
                            this,
                            "Failed to load client",
                            Toast.LENGTH_LONG
                    ).show();
                });
    }


    // ==========================================
    // BUTTONS
    // ==========================================

    private void setupButtons() {

        ImageButton backButton =
                findViewById(R.id.editBackButton);

        backButton.setOnClickListener(v ->
                finish()
        );


        Button saveButton =
                findViewById(R.id.saveClientChanges);

        saveButton.setOnClickListener(v ->
                saveChanges()
        );
    }


    // ==========================================
    // SAVE CHANGES
    // ==========================================

    private void saveChanges() {

        String name =
                nameInput.getText()
                        .toString()
                        .trim();

        String email =
                emailInput.getText()
                        .toString()
                        .trim();

        String phone =
                phoneInput.getText()
                        .toString()
                        .trim();

        String country =
                countryInput.getText()
                        .toString()
                        .trim();

        String company =
                companyInput.getText()
                        .toString()
                        .trim();


        // NAME REQUIRED

        if (name.isEmpty()) {

            nameInput.setError(
                    "Enter client name"
            );

            return;
        }


        // EMAIL REQUIRED

        if (email.isEmpty()) {

            emailInput.setError(
                    "Enter email"
            );

            return;
        }


        Map<String, Object> updates =
                new HashMap<>();

        updates.put(
                "name",
                name
        );

        updates.put(
                "email",
                email
        );

        updates.put(
                "phone",
                phone
        );

        updates.put(
                "country",
                country
        );

        updates.put(
                "company",
                company
        );


        db.collection("clients")
                .document(clientId)
                .update(updates)

                .addOnSuccessListener(v -> {

                    Toast.makeText(
                            this,
                            "Client updated successfully",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                })

                .addOnFailureListener(e -> {

                    Toast.makeText(
                            this,
                            "Failed to update client: "
                                    + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
    }
}