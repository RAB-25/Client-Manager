package com.example.srm30;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.Toast;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;

import java.util.HashMap;
import java.util.Map;

public class signup extends AppCompatActivity {

    // Firebase
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    // Input layouts
    private TextInputLayout usernameInputLayout;
    private TextInputLayout emailInputLayout;
    private TextInputLayout phoneInputLayout;
    private TextInputLayout passwordInputLayout;
    private TextInputLayout confirmPasswordInputLayout;

    // Input fields
    private TextInputEditText usernameEditText;
    private TextInputEditText emailEditText;
    private TextInputEditText phoneEditText;
    private TextInputEditText passwordEditText;
    private TextInputEditText confirmPasswordEditText;

    // Button and login text
    private Button createAccountButton;
    private TextView loginText;

    // Phone number validation
    private PhoneNumberUtil phoneUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_signup);

        // -----------------------------
        // Initialize Firebase
        // -----------------------------

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // -----------------------------
        // Initialize phone validator
        // -----------------------------

        phoneUtil = PhoneNumberUtil.getInstance();

        // -----------------------------
        // Find views
        // -----------------------------

        usernameInputLayout =
                findViewById(R.id.usernameInputLayout);

        emailInputLayout =
                findViewById(R.id.emailInputLayout);

        phoneInputLayout =
                findViewById(R.id.phoneInputLayout);

        passwordInputLayout =
                findViewById(R.id.passwordInputLayout);

        confirmPasswordInputLayout =
                findViewById(R.id.confirmPasswordInputLayout);

        usernameEditText =
                findViewById(R.id.usernameEditText);

        emailEditText =
                findViewById(R.id.emailEditText);

        phoneEditText =
                findViewById(R.id.phoneEditText);

        passwordEditText =
                findViewById(R.id.passwordEditText);

        confirmPasswordEditText =
                findViewById(R.id.confirmPasswordEditText);

        createAccountButton =
                findViewById(R.id.createAccountButton);

        loginText =
                findViewById(R.id.loginText);

        // -----------------------------
        // Phone number input
        // -----------------------------

        phoneEditText.setFilters(
                new InputFilter[]{
                        new InputFilter.LengthFilter(20)
                }
        );

        // -----------------------------
        // Create Account button
        // -----------------------------

        createAccountButton.setOnClickListener(v ->
                createAccount()
        );

        // -----------------------------
        // Login text
        // -----------------------------

        loginText.setOnClickListener(v ->
                openLogin()
        );
    }

    // =========================================================
    // CREATE ACCOUNT
    // =========================================================

    private void createAccount() {

        clearErrors();

        String username =
                getText(usernameEditText);

        String email =
                getText(emailEditText);

        String phone =
                getText(phoneEditText);

        String password =
                getText(passwordEditText);

        String confirmPassword =
                getText(confirmPasswordEditText);

        // =====================================================
        // USERNAME VALIDATION
        // =====================================================

        if (TextUtils.isEmpty(username)) {

            usernameInputLayout.setError(
                    "Enter your username"
            );

            usernameEditText.requestFocus();
            return;
        }

        if (username.length() < 3) {

            usernameInputLayout.setError(
                    "Username must be at least 3 characters"
            );

            usernameEditText.requestFocus();
            return;
        }

        if (!username.matches(
                "^[a-zA-Z0-9_]+$"
        )) {

            usernameInputLayout.setError(
                    "Use only letters, numbers and underscore"
            );

            usernameEditText.requestFocus();
            return;
        }

        // =====================================================
        // EMAIL VALIDATION
        // =====================================================

        if (TextUtils.isEmpty(email)) {

            emailInputLayout.setError(
                    "Enter your email address"
            );

            emailEditText.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS
                .matcher(email)
                .matches()) {

            emailInputLayout.setError(
                    "Enter a valid email address"
            );

            emailEditText.requestFocus();
            return;
        }

        // =====================================================
        // PHONE VALIDATION
        // =====================================================

        if (TextUtils.isEmpty(phone)) {

            phoneInputLayout.setError(
                    "Enter your phone number"
            );

            phoneEditText.requestFocus();
            return;
        }

        String validPhone =
                validatePhoneNumber(phone);

        if (validPhone == null) {

            phoneInputLayout.setError(
                    "Enter a valid international phone number"
            );

            phoneEditText.requestFocus();
            return;
        }

        // =====================================================
        // PASSWORD VALIDATION
        // =====================================================

        if (TextUtils.isEmpty(password)) {

            passwordInputLayout.setError(
                    "Enter a password"
            );

            passwordEditText.requestFocus();
            return;
        }

        if (!isStrongPassword(password)) {

            passwordInputLayout.setError(
                    "Use 8+ characters with uppercase, lowercase, number and special character"
            );

            passwordEditText.requestFocus();
            return;
        }

        // =====================================================
        // CONFIRM PASSWORD
        // =====================================================

        if (TextUtils.isEmpty(confirmPassword)) {

            confirmPasswordInputLayout.setError(
                    "Confirm your password"
            );

            confirmPasswordEditText.requestFocus();
            return;
        }

        if (!password.equals(confirmPassword)) {

            confirmPasswordInputLayout.setError(
                    "Passwords do not match"
            );

            confirmPasswordEditText.requestFocus();
            return;
        }

        // =====================================================
        // EVERYTHING VALID
        // =====================================================

        createFirebaseAccount(
                username,
                email,
                validPhone,
                password
        );
    }

    // =========================================================
    // CREATE FIREBASE ACCOUNT
    // =========================================================

    private void createFirebaseAccount(
            String username,
            String email,
            String phone,
            String password
    ) {

        createAccountButton.setEnabled(false);

        createAccountButton.setText(
                "Creating Account..."
        );

        mAuth.createUserWithEmailAndPassword(
                        email,
                        password
                )
                .addOnCompleteListener(
                        this,
                        task -> {

                            // -----------------------------
                            // Firebase account failed
                            // -----------------------------

                            if (!task.isSuccessful()) {

                                getSharedPreferences("SRM_PREFS", MODE_PRIVATE)
                                        .edit()
                                        .putBoolean("signup_completed", true)
                                        .apply();

                                resetCreateButton();

                                handleFirebaseError(
                                        task.getException()
                                );

                                return;
                            }

                            // -----------------------------
                            // Get Firebase user
                            // -----------------------------

                            FirebaseUser user =
                                    mAuth.getCurrentUser();

                            if (user == null) {

                                resetCreateButton();

                                Toast.makeText(
                                        signup.this,
                                        "Something went wrong. Please try again.",
                                        Toast.LENGTH_LONG
                                ).show();

                                return;
                            }

                            String uid =
                                    user.getUid();

                            // -----------------------------
                            // Create Firestore profile
                            // -----------------------------

                            Map<String, Object> userData =
                                    new HashMap<>();

                            userData.put(
                                    "username",
                                    username
                            );

                            userData.put(
                                    "email",
                                    email
                            );

                            userData.put(
                                    "phone",
                                    phone
                            );

                            userData.put(
                                    "createdAt",
                                    FieldValue.serverTimestamp()
                            );

                            db.collection("users")
                                    .document(uid)
                                    .set(userData)
                                    .addOnSuccessListener(
                                            unused -> {

                                                Toast.makeText(
                                                        signup.this,
                                                        "Account created successfully!",
                                                        Toast.LENGTH_SHORT
                                                ).show();

                                                // Sign out after
                                                // registration.
                                                mAuth.signOut();

                                                openLogin();
                                            }
                                    )
                                    .addOnFailureListener(
                                            e -> {

                                                resetCreateButton();

                                                Toast.makeText(
                                                        signup.this,
                                                        "Account created, but profile setup failed.",
                                                        Toast.LENGTH_LONG
                                                ).show();
                                            }
                                    );
                        }
                );
    }

    // =========================================================
    // PHONE NUMBER VALIDATION
    // =========================================================

    private String validatePhoneNumber(
            String phone
    ) {

        try {

            /*
             * International format examples:
             *
             * +919876543210
             * +14155552671
             * +447911123456
             * +4915123456789
             */

            Phonenumber.PhoneNumber number =
                    phoneUtil.parse(
                            phone,
                            null
                    );

            if (!phoneUtil.isValidNumber(number)) {
                return null;
            }

            return phoneUtil.format(
                    number,
                    PhoneNumberUtil.PhoneNumberFormat.E164
            );

        } catch (NumberParseException e) {

            return null;
        }
    }

    // =========================================================
    // PASSWORD VALIDATION
    // =========================================================

    private boolean isStrongPassword(
            String password
    ) {

        if (password.length() < 8) {
            return false;
        }

        boolean hasUppercase =
                password.matches(
                        ".*[A-Z].*"
                );

        boolean hasLowercase =
                password.matches(
                        ".*[a-z].*"
                );

        boolean hasNumber =
                password.matches(
                        ".*[0-9].*"
                );

        boolean hasSpecialCharacter =
                password.matches(
                        ".*[^a-zA-Z0-9].*"
                );

        return hasUppercase
                && hasLowercase
                && hasNumber
                && hasSpecialCharacter;
    }

    // =========================================================
    // FIREBASE ERROR HANDLING
    // =========================================================

    private void handleFirebaseError(
            Exception exception
    ) {

        if (exception == null) {

            Toast.makeText(
                    this,
                    "Account creation failed.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        String message =
                exception.getMessage();

        if (message == null) {

            Toast.makeText(
                    this,
                    "Account creation failed.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        // Existing email
        if (message.contains(
                "email address is already in use"
        )) {

            emailInputLayout.setError(
                    "This email is already registered"
            );

            emailEditText.requestFocus();

        }

        // Invalid email
        else if (message.contains(
                "badly formatted"
        )) {

            emailInputLayout.setError(
                    "Invalid email address"
            );

            emailEditText.requestFocus();

        }

        // Weak password
        else if (message.contains(
                "weak-password"
        )) {

            passwordInputLayout.setError(
                    "Password is too weak"
            );

            passwordEditText.requestFocus();

        }

        // Other Firebase error
        else {

            Toast.makeText(
                    this,
                    message,
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // =========================================================
    // OPEN LOGIN PAGE
    // =========================================================

    private void openLogin() {

        Intent intent =
                new Intent(
                        signup.this,
                        login.class
                );

        startActivity(intent);

        finish();
    }

    // =========================================================
    // GET TEXT
    // =========================================================

    private String getText(
            TextInputEditText editText
    ) {

        if (editText.getText() == null) {
            return "";
        }

        return editText
                .getText()
                .toString()
                .trim();
    }

    // =========================================================
    // CLEAR ERRORS
    // =========================================================

    private void clearErrors() {

        usernameInputLayout.setError(null);

        emailInputLayout.setError(null);

        phoneInputLayout.setError(null);

        passwordInputLayout.setError(null);

        confirmPasswordInputLayout.setError(null);
    }

    // =========================================================
    // RESET BUTTON
    // =========================================================

    private void resetCreateButton() {

        createAccountButton.setEnabled(true);

        createAccountButton.setText(
                "Create Account"
        );
    }
}