package com.example.srm30;

import android.os.Bundle;
import android.widget.ImageButton;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.view.WindowCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private ImageButton menuButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Modern Android edge-to-edge handling
        WindowCompat.setDecorFitsSystemWindows(
                getWindow(),
                false
        );

        setContentView(R.layout.activity_main);

        // =========================================
        // GET VIEWS
        // =========================================

        drawerLayout = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);
        menuButton = findViewById(R.id.menuButton);

        // =========================================
        // DRAWER UNLOCKED
        // =========================================

        drawerLayout.setDrawerLockMode(
                DrawerLayout.LOCK_MODE_UNLOCKED,
                GravityCompat.START
        );

        // =========================================
        // MENU BUTTON
        // =========================================

        menuButton.setOnClickListener(v -> {

            if (drawerLayout.isDrawerOpen(
                    GravityCompat.START
            )) {

                drawerLayout.closeDrawer(
                        GravityCompat.START
                );

            } else {

                drawerLayout.openDrawer(
                        GravityCompat.START
                );
            }
        });

        // =========================================
        // BACK BUTTON
        // =========================================

        getOnBackPressedDispatcher().addCallback(
                this,
                new OnBackPressedCallback(true) {

                    @Override
                    public void handleOnBackPressed() {

                        if (drawerLayout.isDrawerOpen(
                                GravityCompat.START
                        )) {

                            drawerLayout.closeDrawer(
                                    GravityCompat.START
                            );

                        } else {

                            finish();
                        }
                    }
                }
        );

        // =========================================
        // OPEN DASHBOARD OR TASKS
        // =========================================

        if (savedInstanceState == null) {

            boolean openTasks =
                    getIntent().getBooleanExtra(
                            "openTasks",
                            false
                    );

            if (openTasks) {

                loadFragment(
                        new TasksFragment()
                );

                navigationView.setCheckedItem(
                        R.id.nav_tasks
                );

            } else {

                loadFragment(
                        new DashboardFragment()
                );

                navigationView.setCheckedItem(
                        R.id.nav_dashboard
                );
            }
        }

        // =========================================
        // SIDE MENU
        // =========================================

        navigationView.setNavigationItemSelectedListener(
                item -> {

                    int id = item.getItemId();

                    if (id == R.id.nav_dashboard) {

                        loadFragment(
                                new DashboardFragment()
                        );

                    } else if (id == R.id.nav_profile) {

                        loadFragment(
                                new ProfileFragment()
                        );

                    } else if (id == R.id.nav_tasks) {

                        loadFragment(
                                new TasksFragment()
                        );

                    } else if (id == R.id.nav_clients) {

                        loadFragment(
                                new ClientsFragment()
                        );

                    } else if (id == R.id.nav_about) {

                        android.widget.Toast.makeText(
                                MainActivity.this,
                                "SRM App\nCreated by Rishabh",
                                android.widget.Toast.LENGTH_LONG
                        ).show();

                    } else if (id == R.id.nav_logout) {

                        logout();
                    }

                    drawerLayout.closeDrawer(
                            GravityCompat.START
                    );

                    return true;
                }
        );
    }

    // =========================================
    // LOAD FRAGMENT
    // =========================================

    private void loadFragment(Fragment fragment) {

        getSupportFragmentManager()
                .beginTransaction()
                .replace(
                        R.id.fragmentContainer,
                        fragment
                )
                .commit();
    }

    // =========================================
    // LOGOUT
    // =========================================

    private void logout() {

        FirebaseAuth
                .getInstance()
                .signOut();

        android.content.Intent intent =
                new android.content.Intent(
                        MainActivity.this,
                        login.class
                );

        intent.setFlags(
                android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                        |
                        android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK
        );

        startActivity(intent);

        finish();
    }
}