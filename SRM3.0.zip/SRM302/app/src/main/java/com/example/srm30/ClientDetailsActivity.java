package com.example.srm30;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

public class ClientDetailsActivity extends AppCompatActivity {

    private FirebaseFirestore db;

    private String clientId;

    private String clientName;
    private String clientEmail;
    private String clientPhone;
    private String clientCountry;
    private String clientCompany;
    private String clientWebsite;
    private String clientPhotoUrl;

    private ImageView clientPhoto;
    private TextView clientNameView;
    private TextView clientEmailView;
    private TextView clientPhoneView;
    private TextView clientCountryView;
    private TextView clientCompanyView;
    private TextView clientWebsiteView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_client_details);

        db = FirebaseFirestore.getInstance();

        getClientData();

        initializeViews();

        displayClientData();

        setupButtons();
    }

    // ==========================================
    // GET CLIENT DATA
    // ==========================================

    private void getClientData() {

        Intent intent = getIntent();

        clientId =
                intent.getStringExtra("clientId");

        clientName =
                intent.getStringExtra("name");

        clientEmail =
                intent.getStringExtra("email");

        clientPhone =
                intent.getStringExtra("phone");

        clientCountry =
                intent.getStringExtra("country");

        clientCompany =
                intent.getStringExtra("company");

        clientWebsite =
                intent.getStringExtra("website");

        clientPhotoUrl =
                intent.getStringExtra("photoUrl");
    }


    // ==========================================
    // INITIALIZE VIEWS
    // ==========================================

    private void initializeViews() {

        clientPhoto =
                findViewById(R.id.clientDetailPhoto);

        clientNameView =
                findViewById(R.id.clientDetailName);

        clientEmailView =
                findViewById(R.id.clientDetailEmail);

        clientPhoneView =
                findViewById(R.id.clientDetailPhone);

        clientCountryView =
                findViewById(R.id.clientDetailCountry);

        clientCompanyView =
                findViewById(R.id.clientDetailCompany);

        clientWebsiteView =
                findViewById(R.id.clientDetailWebsite);
    }


    // ==========================================
    // DISPLAY CLIENT
    // ==========================================

    private void displayClientData() {

        clientNameView.setText(
                safeText(clientName, "Client")
        );

        clientEmailView.setText(
                safeText(clientEmail, "No email")
        );

        clientPhoneView.setText(
                safeText(clientPhone, "No phone")
        );

        clientCountryView.setText(
                safeText(clientCountry, "No country")
        );

        clientCompanyView.setText(
                safeText(clientCompany, "No company")
        );

        clientWebsiteView.setText(
                safeText(clientWebsite, "No website")
        );

        if (clientPhotoUrl != null &&
                !clientPhotoUrl.isEmpty()) {

            loadImage(clientPhotoUrl);

        } else {

            clientPhoto.setImageResource(
                    R.drawable.profile_placeholder
            );
        }
    }


    private String safeText(
            String value,
            String fallback) {

        if (value == null ||
                value.trim().isEmpty()) {

            return fallback;
        }

        return value;
    }


    // ==========================================
    // BUTTONS
    // ==========================================

    private void setupButtons() {

        ImageButton backButton =
                findViewById(R.id.clientBackButton);

        backButton.setOnClickListener(v ->
                finish()
        );


        ImageButton emailButton =
                findViewById(R.id.clientEmailButton);

        emailButton.setOnClickListener(v ->
                openEmail()
        );


        ImageButton phoneButton =
                findViewById(R.id.clientPhoneButton);

        phoneButton.setOnClickListener(v ->
                callClient()
        );


        Button taskButton =
                findViewById(R.id.clientTaskButton);

        taskButton.setOnClickListener(v ->
                openTask()
        );


        Button scriptButton =
                findViewById(R.id.clientScriptButton);

        scriptButton.setOnClickListener(v ->
                openScriptGenerator()
        );


        Button scriptsButton =
                findViewById(R.id.clientScriptsButton);

        scriptsButton.setOnClickListener(v ->
                openScripts()
        );


        Button removeButton =
                findViewById(R.id.removeClientButton);

        removeButton.setOnClickListener(v ->
                confirmDelete()
        );


        Button editButton =
                findViewById(R.id.editClientButton);

        editButton.setOnClickListener(v ->
                openEditClient()
        );
    }


    // ==========================================
    // EMAIL
    // ==========================================

    private void openEmail() {

        if (clientEmail == null ||
                clientEmail.trim().isEmpty()) {

            Toast.makeText(
                    this,
                    "No email available",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        Intent intent =
                new Intent(Intent.ACTION_SENDTO);

        intent.setData(
                Uri.parse(
                        "mailto:" + clientEmail
                )
        );

        intent.putExtra(
                Intent.EXTRA_SUBJECT,
                "Hello " + clientName
        );

        try {

            startActivity(intent);

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "No email app found",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // ==========================================
    // PHONE
    // ==========================================

    private void callClient() {

        if (clientPhone == null ||
                clientPhone.trim().isEmpty()) {

            Toast.makeText(
                    this,
                    "No phone number available",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        Intent intent =
                new Intent(
                        Intent.ACTION_DIAL
                );

        intent.setData(
                Uri.parse(
                        "tel:" + clientPhone
                )
        );

        startActivity(intent);
    }


    // ==========================================
    // TASK
    // ==========================================

    private void openTask() {

        Intent intent = new Intent(
                this,
                MainActivity.class
        );

        intent.putExtra("openTasks", true);
        intent.putExtra("clientId", clientId);
        intent.putExtra("clientName", clientName);

        startActivity(intent);
        finish();
    }


    // ==========================================
    // SCRIPTS
    // ==========================================

    private void openScriptGenerator() {

        Intent intent =
                new Intent(
                        this,
                        ScriptGeneratorActivity.class
                );

        intent.putExtra(
                "clientId",
                clientId
        );

        intent.putExtra(
                "clientName",
                clientName
        );

        startActivity(intent);
    }

    private void openScripts() {

        Intent intent =
                new Intent(
                        this,
                        ScriptsActivity.class
                );

        intent.putExtra(
                "clientId",
                clientId
        );

        intent.putExtra(
                "clientName",
                clientName
        );

        startActivity(intent);
    }


    // ==========================================
    // EDIT
    // ==========================================

    private void openEditClient() {

        Intent intent =
                new Intent(
                        this,
                        EditClientActivity.class
                );

        intent.putExtra(
                "clientId",
                clientId
        );

        startActivity(intent);
    }


    // ==========================================
    // DELETE CONFIRMATION
    // ==========================================

    private void confirmDelete() {

        new AlertDialog.Builder(this)

                .setTitle("Remove Client")

                .setMessage(
                        "Are you sure you want to remove "
                                + safeText(
                                clientName,
                                "this client"
                        )
                                + "?"
                )

                .setNegativeButton(
                        "CANCEL",
                        null
                )

                .setPositiveButton(
                        "REMOVE",
                        (dialog, which) ->
                                deleteClient()
                )

                .show();
    }


    // ==========================================
    // DELETE CLIENT
    // ==========================================

    private void deleteClient() {

        if (clientId == null ||
                clientId.trim().isEmpty()) {

            Toast.makeText(
                    this,
                    "Client ID missing",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        db.collection("clients")
                .document(clientId)
                .delete()
                .addOnSuccessListener(v -> {

                    Toast.makeText(
                            this,
                            "Client removed",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                })

                .addOnFailureListener(e ->
                        Toast.makeText(
                                this,
                                "Failed to remove client",
                                Toast.LENGTH_LONG
                        ).show()
                );
    }


    // ==========================================
    // LOAD PHOTO
    // ==========================================

    private void loadImage(String url) {

        new Thread(() -> {

            try {

                java.net.URL imageUrl =
                        new java.net.URL(url);

                java.net.HttpURLConnection connection =
                        (java.net.HttpURLConnection)
                                imageUrl.openConnection();

                connection.connect();

                java.io.InputStream input =
                        connection.getInputStream();

                android.graphics.Bitmap bitmap =
                        android.graphics.BitmapFactory
                                .decodeStream(input);

                runOnUiThread(() ->
                        clientPhoto.setImageBitmap(bitmap)
                );

                input.close();

                connection.disconnect();

            } catch (Exception e) {

                runOnUiThread(() ->
                        clientPhoto.setImageResource(
                                R.drawable.profile_placeholder
                        )
                );
            }

        }).start();
    }
}