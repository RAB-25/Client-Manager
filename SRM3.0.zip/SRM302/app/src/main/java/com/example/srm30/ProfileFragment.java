package com.example.srm30;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class ProfileFragment extends Fragment {

    private static final int PICK_IMAGE = 100;

    private ImageView profilePhoto;

    private TextView profileName;
    private TextView profileOccupation;
    private TextView profileAgency;
    private TextView profileEmail;
    private TextView profilePhone;
    private TextView profileOccupationDetail;
    private TextView profileAgencyDetail;

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {

        View view = inflater.inflate(
                R.layout.fragment_profile,
                container,
                false
        );

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        profilePhoto = view.findViewById(R.id.profilePhoto);

        profileName = view.findViewById(R.id.profileName);
        profileOccupation = view.findViewById(R.id.profileOccupation);
        profileAgency = view.findViewById(R.id.profileAgency);
        profileEmail = view.findViewById(R.id.profileEmail);
        profilePhone = view.findViewById(R.id.profilePhone);

        profileOccupationDetail =
                view.findViewById(R.id.profileOccupationDetail);

        profileAgencyDetail =
                view.findViewById(R.id.profileAgencyDetail);

        Button uploadButton =
                view.findViewById(R.id.uploadPhotoTextButton);

        profilePhoto.setOnClickListener(v -> openGallery());

        view.findViewById(R.id.uploadPhotoButton)
                .setOnClickListener(v -> openGallery());

        uploadButton.setOnClickListener(v -> openGallery());

        loadProfile();

        return view;
    }

    private void loadProfile() {

        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            return;
        }

        loadLocalPhoto(user);

        if (user.getEmail() != null) {
            profileEmail.setText(user.getEmail());
        }

        db.collection("users")
                .document(user.getUid())
                .get()
                .addOnSuccessListener(document -> {

                    if (!document.exists()) {
                        return;
                    }

                    String name = document.getString("name");

                    if (name == null || name.trim().isEmpty()) {
                        name = document.getString("username");
                    }

                    String occupation =
                            document.getString("occupation");

                    String agency =
                            document.getString("agencyName");

                    String phone =
                            document.getString("phone");

                    if (name != null && !name.isEmpty()) {
                        profileName.setText(name);
                    }

                    if (occupation != null &&
                            !occupation.isEmpty()) {

                        profileOccupation.setText(occupation);

                        profileOccupationDetail.setText(
                                occupation
                        );
                    }

                    if (agency != null &&
                            !agency.isEmpty()) {

                        profileAgency.setText(agency);

                        profileAgencyDetail.setText(agency);
                    }

                    if (phone != null && !phone.isEmpty()) {
                        profilePhone.setText(phone);
                    }
                });
    }

    private void loadLocalPhoto(FirebaseUser user) {

        String savedUri = requireContext()
                .getSharedPreferences(
                        "SRM_PROFILE_PHOTOS",
                        android.content.Context.MODE_PRIVATE
                )
                .getString(
                        "photo_" + user.getUid(),
                        null
                );

        if (savedUri == null || savedUri.isEmpty()) {
            return;
        }

        try {
            profilePhoto.setImageURI(
                    Uri.parse(savedUri)
            );
        } catch (Exception ignored) {
        }
    }

    private void openGallery() {

        Intent intent = new Intent(
                Intent.ACTION_OPEN_DOCUMENT
        );

        intent.setType("image/*");

        intent.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        intent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        );

        startActivityForResult(
                intent,
                PICK_IMAGE
        );
    }

    @Override
    public void onActivityResult(
            int requestCode,
            int resultCode,
            @Nullable Intent data
    ) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (requestCode != PICK_IMAGE ||
                resultCode != Activity.RESULT_OK ||
                data == null ||
                data.getData() == null) {
            return;
        }

        saveLocalPhoto(
                data.getData(),
                data
        );
    }

    private void saveLocalPhoto(
            Uri imageUri,
            Intent data
    ) {

        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            return;
        }

        try {

            int takeFlags = data.getFlags()
                    & Intent.FLAG_GRANT_READ_URI_PERMISSION;

            requireContext()
                    .getContentResolver()
                    .takePersistableUriPermission(
                            imageUri,
                            takeFlags
                    );

        } catch (SecurityException ignored) {
        }

        requireContext()
                .getSharedPreferences(
                        "SRM_PROFILE_PHOTOS",
                        android.content.Context.MODE_PRIVATE
                )
                .edit()
                .putString(
                        "photo_" + user.getUid(),
                        imageUri.toString()
                )
                .apply();

        profilePhoto.setImageURI(imageUri);

        Toast.makeText(
                requireContext(),
                "Profile photo updated!",
                Toast.LENGTH_SHORT
        ).show();
    }
}