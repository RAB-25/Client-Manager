package com.example.srm30;

public class ClientModel {

    String id = "";

    String name = "";
    String email = "";
    String phone = "";
    String country = "";
    String company = "";
    String photoUrl = "";
    String website = "";
}