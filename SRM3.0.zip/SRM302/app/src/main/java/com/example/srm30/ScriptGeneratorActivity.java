package com.example.srm30;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ScriptGeneratorActivity extends AppCompatActivity {

    private String clientId;
    private String clientName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_script_generator);

        // Get client information
        clientId =
                getIntent().getStringExtra("clientId");

        clientName =
                getIntent().getStringExtra("clientName");


        // Show client name
        TextView clientNameView =
                findViewById(R.id.scriptClientName);

        if (clientName != null &&
                !clientName.trim().isEmpty()) {

            clientNameView.setText(
                    clientName + "'s Script"
            );
        }


        // BACK BUTTON
        ImageButton backButton =
                findViewById(R.id.scriptGeneratorBackButton);

        backButton.setOnClickListener(v ->
                finish()
        );
    }
}