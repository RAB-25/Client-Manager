package com.example.srm30;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SplashActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;

    // Small delay so the splash/logo doesn't disappear instantly
    private static final int SPLASH_DELAY = 1200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_splash);

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();

        new Handler().postDelayed(() -> {

            FirebaseUser currentUser =
                    mAuth.getCurrentUser();

            if (currentUser != null) {

                // ==========================================
                // USER IS ALREADY LOGGED IN
                // ==========================================

                openMainActivity();

            } else {

                // ==========================================
                // NO USER IS LOGGED IN
                // ==========================================
                //
                // We need to know whether this is the
                // first time the app has been opened.
                //

                boolean signupCompleted =
                        getSharedPreferences(
                                "SRM_PREFS",
                                MODE_PRIVATE
                        ).getBoolean(
                                "signup_completed",
                                false
                        );

                if (signupCompleted) {

                    // User has already created an account
                    // but is currently logged out.

                    openLogin();

                } else {

                    // First time using the app.

                    openSignup();
                }
            }

        }, SPLASH_DELAY);
    }

    // =====================================================
    // OPEN SIGNUP
    // =====================================================

    private void openSignup() {

        Intent intent =
                new Intent(
                        SplashActivity.this,
                        signup.class
                );

        startActivity(intent);
        finish();
    }

    // =====================================================
    // OPEN LOGIN
    // =====================================================

    private void openLogin() {

        Intent intent =
                new Intent(
                        SplashActivity.this,
                        login.class
                );

        startActivity(intent);
        finish();
    }

    // =====================================================
    // OPEN MAIN ACTIVITY
    // =====================================================

    private void openMainActivity() {

        Intent intent =
                new Intent(
                        SplashActivity.this,
                        MainActivity.class
                );

        startActivity(intent);
        finish();
    }
}