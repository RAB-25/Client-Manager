package com.example.srm30;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class login extends AppCompatActivity {

    // Firebase
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    // Input layouts
    private TextInputLayout usernameInputLayout;
    private TextInputLayout passwordInputLayout;

    // Input fields
    private TextInputEditText usernameEditText;
    private TextInputEditText passwordEditText;

    // Buttons / TextViews
    private AppCompatButton loginButton;
    private TextView forgotPassword;
    private TextView createAccountText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        // ==========================================
        // INITIALIZE FIREBASE
        // ==========================================

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // ==========================================
        // FIND VIEWS
        // ==========================================

        usernameInputLayout =
                findViewById(R.id.usernameInputLayout);

        passwordInputLayout =
                findViewById(R.id.passwordInputLayout);

        usernameEditText =
                findViewById(R.id.usernameEditText);

        passwordEditText =
                findViewById(R.id.passwordEditText);

        loginButton =
                findViewById(R.id.loginButton);

        forgotPassword =
                findViewById(R.id.forgotPassword);

        createAccountText =
                findViewById(R.id.createAccountText);

        // ==========================================
        // LOGIN
        // ==========================================

        loginButton.setOnClickListener(v ->
                loginUser()
        );

        // ==========================================
        // FORGOT PASSWORD
        // ==========================================

        forgotPassword.setOnClickListener(v ->
                resetPassword()
        );

        // ==========================================
        // CREATE ACCOUNT
        // ==========================================

        createAccountText.setOnClickListener(v ->
                openSignup()
        );
    }

    // =========================================================
    // LOGIN USER
    // =========================================================

    private void loginUser() {

        clearErrors();

        String username =
                getText(usernameEditText);

        String password =
                getText(passwordEditText);

        // ==========================================
        // USERNAME VALIDATION
        // ==========================================

        if (TextUtils.isEmpty(username)) {

            usernameInputLayout.setError(
                    "Enter your username"
            );

            usernameEditText.requestFocus();

            return;
        }

        // ==========================================
        // PASSWORD VALIDATION
        // ==========================================

        if (TextUtils.isEmpty(password)) {

            passwordInputLayout.setError(
                    "Enter your password"
            );

            passwordEditText.requestFocus();

            return;
        }

        // ==========================================
        // START LOGIN
        // ==========================================

        loginButton.setEnabled(false);

        loginButton.setText(
                "Logging in..."
        );

        // ==========================================
        // FIND USERNAME IN FIRESTORE
        // ==========================================

        db.collection("users")
                .whereEqualTo("username", username)
                .limit(1)
                .get()
                .addOnSuccessListener(
                        querySnapshot -> {

                            // ==================================
                            // USERNAME NOT FOUND
                            // ==================================

                            if (querySnapshot.isEmpty()) {

                                resetLoginButton();

                                usernameInputLayout.setError(
                                        "Username not found"
                                );

                                usernameEditText.requestFocus();

                                return;
                            }

                            // ==================================
                            // GET USER DATA
                            // ==================================

                            String email =
                                    querySnapshot
                                            .getDocuments()
                                            .get(0)
                                            .getString("email");

                            if (email == null ||
                                    email.trim().isEmpty()) {

                                resetLoginButton();

                                Toast.makeText(
                                        login.this,
                                        "Account information is incomplete.",
                                        Toast.LENGTH_LONG
                                ).show();

                                return;
                            }

                            // ==================================
                            // FIREBASE AUTH LOGIN
                            // ==================================

                            signInWithFirebase(
                                    email,
                                    password
                            );
                        }
                )
                .addOnFailureListener(
                        e -> {

                            resetLoginButton();

                            Toast.makeText(
                                    login.this,
                                    "Unable to connect to the server. Please try again.",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                );
    }

    // =========================================================
    // FIREBASE EMAIL/PASSWORD LOGIN
    // =========================================================

    private void signInWithFirebase(
            String email,
            String password
    ) {

        mAuth.signInWithEmailAndPassword(
                        email,
                        password
                )
                .addOnCompleteListener(
                        this,
                        task -> {

                            if (task.isSuccessful()) {

                                // ==================================
                                // LOGIN SUCCESSFUL
                                // ==================================

                                Toast.makeText(
                                        login.this,
                                        "Login successful!",
                                        Toast.LENGTH_SHORT
                                ).show();

                                openMainActivity();

                            } else {

                                // ==================================
                                // LOGIN FAILED
                                // ==================================

                                resetLoginButton();

                                handleLoginError(
                                        task.getException()
                                );
                            }
                        }
                );
    }

    // =========================================================
    // FORGOT PASSWORD
    // =========================================================

    private void resetPassword() {

        clearErrors();

        String username =
                getText(usernameEditText);

        // ==========================================
        // USERNAME EMPTY
        // ==========================================

        if (TextUtils.isEmpty(username)) {

            usernameInputLayout.setError(
                    "Enter your username first"
            );

            usernameEditText.requestFocus();

            return;
        }

        // ==========================================
        // FIND EMAIL FROM USERNAME
        // ==========================================

        Toast.makeText(
                login.this,
                "Finding your account...",
                Toast.LENGTH_SHORT
        ).show();

        db.collection("users")
                .whereEqualTo("username", username)
                .limit(1)
                .get()
                .addOnSuccessListener(
                        querySnapshot -> {

                            // ==================================
                            // USERNAME NOT FOUND
                            // ==================================

                            if (querySnapshot.isEmpty()) {

                                usernameInputLayout.setError(
                                        "Username not found"
                                );

                                usernameEditText.requestFocus();

                                return;
                            }

                            // ==================================
                            // GET EMAIL
                            // ==================================

                            String email =
                                    querySnapshot
                                            .getDocuments()
                                            .get(0)
                                            .getString("email");

                            if (email == null ||
                                    email.trim().isEmpty()) {

                                Toast.makeText(
                                        login.this,
                                        "No email is linked to this account.",
                                        Toast.LENGTH_LONG
                                ).show();

                                return;
                            }

                            // ==================================
                            // SEND RESET EMAIL
                            // ==================================

                            sendPasswordResetEmail(email);
                        }
                )
                .addOnFailureListener(
                        e -> {

                            Toast.makeText(
                                    login.this,
                                    "Unable to find your account. Please try again.",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                );
    }

    // =========================================================
    // SEND PASSWORD RESET EMAIL
    // =========================================================

    private void sendPasswordResetEmail(
            String email
    ) {

        Toast.makeText(
                login.this,
                "Sending password reset email...",
                Toast.LENGTH_SHORT
        ).show();

        mAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener(
                        task -> {

                            if (task.isSuccessful()) {

                                Toast.makeText(
                                        login.this,
                                        "Password reset email sent!",
                                        Toast.LENGTH_LONG
                                ).show();

                            } else {

                                Toast.makeText(
                                        login.this,
                                        "Unable to send reset email. Please try again.",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                );
    }

    // =========================================================
    // LOGIN ERROR
    // =========================================================

    private void handleLoginError(
            Exception exception
    ) {

        if (exception == null) {

            Toast.makeText(
                    this,
                    "Login failed. Please try again.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        String message =
                exception.getMessage();

        if (message == null) {

            Toast.makeText(
                    this,
                    "Login failed. Please try again.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        // ==========================================
        // WRONG PASSWORD / INVALID CREDENTIALS
        // ==========================================

        if (message.contains(
                "password is invalid"
        ) || message.contains(
                "invalid-credential"
        )) {

            passwordInputLayout.setError(
                    "Incorrect username or password"
            );

            passwordEditText.requestFocus();

        }

        // ==========================================
        // USER NOT FOUND
        // ==========================================

        else if (message.contains(
                "no user record"
        )) {

            usernameInputLayout.setError(
                    "Account not found"
            );

            usernameEditText.requestFocus();

        }

        // ==========================================
        // OTHER ERROR
        // ==========================================

        else {

            Toast.makeText(
                    this,
                    "Login failed. Please check your details.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // =========================================================
    // OPEN MAIN ACTIVITY
    // =========================================================

    private void openMainActivity() {

        Intent intent =
                new Intent(
                        login.this,
                        MainActivity.class
                );

        startActivity(intent);

        finish();
    }

    // =========================================================
    // OPEN SIGNUP
    // =========================================================

    private void openSignup() {

        Intent intent =
                new Intent(
                        login.this,
                        signup.class
                );

        startActivity(intent);

        finish();
    }

    // =========================================================
    // GET TEXT
    // =========================================================

    private String getText(
            TextInputEditText editText
    ) {

        if (editText.getText() == null) {
            return "";
        }

        return editText
                .getText()
                .toString()
                .trim();
    }

    // =========================================================
    // CLEAR ERRORS
    // =========================================================

    private void clearErrors() {

        usernameInputLayout.setError(null);

        passwordInputLayout.setError(null);
    }

    // =========================================================
    // RESET LOGIN BUTTON
    // =========================================================

    private void resetLoginButton() {

        loginButton.setEnabled(true);

        loginButton.setText(
                "Login"
        );
    }
}