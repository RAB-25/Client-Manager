package com.example.srm30;

import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class ScriptsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_scripts);

        ImageButton backButton =
                findViewById(R.id.scriptsBackButton);

        backButton.setOnClickListener(v ->
                finish()
        );
    }
}