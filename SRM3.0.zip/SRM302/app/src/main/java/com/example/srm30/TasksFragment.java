package com.example.srm30;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;

public class TasksFragment extends Fragment {

    private LinearLayout taskContainer;
    private TextView emptyTasksText;

    private FirebaseFirestore db;
    private FirebaseStorage storage;

    private Uri selectedFileUri;
    private TextView selectedFileText;

    private final ActivityResultLauncher<String> filePicker =
            registerForActivityResult(
                    new ActivityResultContracts.GetContent(),
                    uri -> {
                        if (uri == null) {
                            return;
                        }

                        selectedFileUri = uri;

                        if (selectedFileText != null) {
                            selectedFileText.setText(
                                    "Attached: " + getFileName(uri)
                            );
                            selectedFileText.setTextColor(
                                    Color.parseColor("#D4AF37")
                            );
                        }
                    }
            );

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {
        View view = inflater.inflate(
                R.layout.fragment_tasks,
                container,
                false
        );

        taskContainer = view.findViewById(R.id.taskContainer);
        emptyTasksText = view.findViewById(R.id.emptyTasksText);

        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();

        view.findViewById(R.id.newTaskButton)
                .setOnClickListener(v -> showNewTaskDialog());

        loadTasks();

        return view;
    }

    private void showNewTaskDialog() {
        selectedFileUri = null;

        View dialogView = getLayoutInflater().inflate(
                R.layout.dialog_add_task,
                null
        );

        EditText titleInput = dialogView.findViewById(R.id.taskTitleInput);
        EditText descriptionInput = dialogView.findViewById(R.id.taskDescriptionInput);
        Button attachButton = dialogView.findViewById(R.id.attachFileButton);
        selectedFileText = dialogView.findViewById(R.id.selectedFileText);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        attachButton.setOnClickListener(v ->
                filePicker.launch("*/*")
        );

        dialogView.findViewById(R.id.cancelTaskButton)
                .setOnClickListener(v -> dialog.dismiss());

        dialogView.findViewById(R.id.addTaskButton)
                .setOnClickListener(v -> {
                    String title = titleInput.getText().toString().trim();
                    String description = descriptionInput.getText().toString().trim();

                    if (title.isEmpty()) {
                        titleInput.setError("Please enter a title");
                        titleInput.requestFocus();
                        return;
                    }

                    dialog.dismiss();
                    createTask(title, description);
                });

        dialog.show();
    }

    private void createTask(String title, String description) {
        if (selectedFileUri == null) {
            saveTask(title, description, null, null, null);
            return;
        }

        Toast.makeText(
                requireContext(),
                "Uploading attachment...",
                Toast.LENGTH_SHORT
        ).show();

        String fileName = getFileName(selectedFileUri);
        String fileType = requireContext()
                .getContentResolver()
                .getType(selectedFileUri);

        String safeFileName = fileName.replaceAll("[^a-zA-Z0-9._-]", "_");

        StorageReference fileReference = storage
                .getReference()
                .child("task_attachments")
                .child(System.currentTimeMillis() + "_" + safeFileName);

        fileReference.putFile(selectedFileUri)
                .continueWithTask(task -> {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }

                    return fileReference.getDownloadUrl();
                })
                .addOnSuccessListener(downloadUri ->
                        saveTask(
                                title,
                                description,
                                downloadUri.toString(),
                                fileName,
                                fileType
                        )
                )
                .addOnFailureListener(e ->
                        Toast.makeText(
                                requireContext(),
                                "Attachment upload failed: " + e.getMessage(),
                                Toast.LENGTH_LONG
                        ).show()
                );
    }

    private void saveTask(
            String title,
            String description,
            @Nullable String attachmentUrl,
            @Nullable String attachmentName,
            @Nullable String attachmentType
    ) {
        Map<String, Object> taskData = new HashMap<>();

        // Keep "name" so your existing dashboard count/list still works.
        taskData.put("name", title);
        taskData.put("description", description);
        taskData.put("status", "pending");
        taskData.put("createdAt", FieldValue.serverTimestamp());

        if (attachmentUrl != null) {
            taskData.put("attachmentUrl", attachmentUrl);
            taskData.put("attachmentName", attachmentName);
            taskData.put("attachmentType", attachmentType);
        }

        db.collection("tasks")
                .add(taskData)
                .addOnSuccessListener(documentReference ->
                        Toast.makeText(
                                requireContext(),
                                "Task added successfully",
                                Toast.LENGTH_SHORT
                        ).show()
                )
                .addOnFailureListener(e ->
                        Toast.makeText(
                                requireContext(),
                                "Failed to add task: " + e.getMessage(),
                                Toast.LENGTH_LONG
                        ).show()
                );
    }

    private void loadTasks() {
        db.collection("tasks")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .addSnapshotListener((snapshot, error) -> {
                    if (!isAdded()) {
                        return;
                    }

                    if (error != null) {
                        Toast.makeText(
                                requireContext(),
                                "Error loading tasks",
                                Toast.LENGTH_SHORT
                        ).show();
                        return;
                    }

                    if (snapshot == null) {
                        return;
                    }

                    taskContainer.removeAllViews();

                    int pendingCount = 0;

                    for (com.google.firebase.firestore.DocumentSnapshot document
                            : snapshot.getDocuments()) {

                        String title = document.getString("name");
                        String status = document.getString("status");

                        if (title == null || !"pending".equals(status)) {
                            continue;
                        }

                        pendingCount++;

                        addTaskView(
                                document.getId(),
                                title,
                                document.getString("description"),
                                document.getString("attachmentUrl"),
                                document.getString("attachmentName"),
                                document.getString("attachmentType")
                        );
                    }

                    emptyTasksText.setVisibility(
                            pendingCount == 0 ? View.VISIBLE : View.GONE
                    );
                });
    }

    private void addTaskView(
            String documentId,
            String title,
            @Nullable String description,
            @Nullable String attachmentUrl,
            @Nullable String attachmentName,
            @Nullable String attachmentType
    ) {
        LinearLayout card = new LinearLayout(requireContext());
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(14), dp(12), dp(14));
        card.setBackgroundResource(R.drawable.dashboard_card);

        LinearLayout topRow = new LinearLayout(requireContext());
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        topRow.setOrientation(LinearLayout.HORIZONTAL);

        TextView titleText = new TextView(requireContext());
        titleText.setText("○  " + title);
        titleText.setTextColor(getResources().getColor(R.color.white));
        titleText.setTextSize(17);
        titleText.setTypeface(null, android.graphics.Typeface.BOLD);
        titleText.setMaxLines(2);

        topRow.addView(
                titleText,
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1)
        );

        ImageButton deleteButton = new ImageButton(requireContext());
        deleteButton.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        deleteButton.setColorFilter(Color.rgb(220, 80, 80));
        deleteButton.setBackgroundColor(Color.TRANSPARENT);
        deleteButton.setContentDescription("Delete task");

        topRow.addView(
                deleteButton,
                new LinearLayout.LayoutParams(dp(44), dp(44))
        );

        card.addView(topRow);

        if (description != null && !description.trim().isEmpty()) {
            TextView descriptionText = new TextView(requireContext());
            descriptionText.setText(description);
            descriptionText.setTextColor(Color.parseColor("#AAB4C0"));
            descriptionText.setTextSize(14);
            descriptionText.setPadding(dp(8), dp(5), dp(8), dp(4));

            card.addView(descriptionText);
        }

        if (attachmentUrl != null && !attachmentUrl.isEmpty()) {
            Button openAttachmentButton = new Button(requireContext());

            String fileLabel = attachmentName == null
                    ? "Open attachment"
                    : attachmentName;

            openAttachmentButton.setText("📎 " + fileLabel);
            openAttachmentButton.setAllCaps(false);
            openAttachmentButton.setTextColor(Color.parseColor("#D4AF37"));
            openAttachmentButton.setTextSize(13);
            openAttachmentButton.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            openAttachmentButton.setBackgroundColor(Color.TRANSPARENT);
            openAttachmentButton.setOnClickListener(v ->
                    openAttachment(attachmentUrl, attachmentType)
            );

            card.addView(
                    openAttachmentButton,
                    new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            dp(42)
                    )
            );
        }

        deleteButton.setOnClickListener(v ->
                new AlertDialog.Builder(requireContext())
                        .setTitle("Delete Task?")
                        .setMessage("Are you sure you want to delete \"" + title + "\"?")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton(
                                "Delete",
                                (dialog, which) -> deleteTask(documentId)
                        )
                        .show()
        );

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 0, 0, dp(10));

        taskContainer.addView(card, cardParams);
    }

    private void openAttachment(String attachmentUrl, @Nullable String attachmentType) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(
                    Uri.parse(attachmentUrl),
                    attachmentType == null ? "*/*" : attachmentType
            );
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            startActivity(Intent.createChooser(intent, "Open attachment"));
        } catch (Exception e) {
            Toast.makeText(
                    requireContext(),
                    "No app found to open this attachment",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void deleteTask(String documentId) {
        db.collection("tasks")
                .document(documentId)
                .delete()
                .addOnSuccessListener(unused ->
                        Toast.makeText(
                                requireContext(),
                                "Task deleted",
                                Toast.LENGTH_SHORT
                        ).show()
                )
                .addOnFailureListener(e ->
                        Toast.makeText(
                                requireContext(),
                                "Could not delete task",
                                Toast.LENGTH_SHORT
                        ).show()
                );
    }

    private String getFileName(Uri uri) {
        String fileName = "attachment";

        try (android.database.Cursor cursor = requireContext()
                .getContentResolver()
                .query(uri, null, null, null, null)) {

            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);

                if (nameIndex >= 0) {
                    fileName = cursor.getString(nameIndex);
                }
            }
        }

        return fileName;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}