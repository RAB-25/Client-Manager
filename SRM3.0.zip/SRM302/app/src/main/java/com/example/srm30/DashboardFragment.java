package com.example.srm30;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.firestore.FirebaseFirestore;

public class DashboardFragment extends Fragment {

    private TextView clientCount;
    private TextView taskCount;
    private TextView pendingCount;
    private TextView leadCount;

    private FirebaseFirestore db;

    private int leads = 0;

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(
                R.layout.fragment_dashboard,
                container,
                false
        );

        clientCount = view.findViewById(R.id.clientCount);
        taskCount = view.findViewById(R.id.taskCount);
        pendingCount = view.findViewById(R.id.pendingCount);
        leadCount = view.findViewById(R.id.leadCount);

        TextView plusLead = view.findViewById(R.id.plusLead);
        TextView minusLead = view.findViewById(R.id.minusLead);

        db = FirebaseFirestore.getInstance();

        // PLUS LEAD
        plusLead.setOnClickListener(v -> {

            leads++;

            leadCount.setText(String.valueOf(leads));
        });

        // MINUS LEAD
        minusLead.setOnClickListener(v -> {

            if (leads > 0) {
                leads--;
            }

            leadCount.setText(String.valueOf(leads));
        });

        listenForClients();
        listenForTasks();

        return view;
    }

    // ==========================================
    // CLIENT COUNT
    // ==========================================

    private void listenForClients() {

        db.collection("clients")
                .addSnapshotListener((snapshot, error) -> {

                    if (error != null || snapshot == null) {
                        return;
                    }

                    clientCount.setText(
                            String.valueOf(snapshot.size())
                    );
                });
    }

    // ==========================================
    // TASK COUNT
    // ==========================================

    private void listenForTasks() {

        db.collection("tasks")
                .addSnapshotListener((snapshot, error) -> {

                    if (error != null || snapshot == null) {
                        return;
                    }

                    int total = snapshot.size();
                    int pending = 0;

                    for (com.google.firebase.firestore.DocumentSnapshot document
                            : snapshot.getDocuments()) {

                        String status = document.getString("status");

                        if ("pending".equals(status)) {
                            pending++;
                        }
                    }

                    taskCount.setText(
                            String.valueOf(total)
                    );

                    pendingCount.setText(
                            String.valueOf(pending)
                    );
                });
    }
}