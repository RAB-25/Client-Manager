package com.example.srm30;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ClientAdapter
        extends RecyclerView.Adapter<ClientAdapter.ViewHolder> {

    private final List<ClientModel> allClients = new ArrayList<>();

    private final List<ClientModel> filteredClients = new ArrayList<>();


    // ==========================================
    // SET CLIENTS
    // ==========================================

    public void setClients(List<ClientModel> clients) {

        allClients.clear();
        allClients.addAll(clients);

        filteredClients.clear();
        filteredClients.addAll(clients);

        notifyDataSetChanged();
    }


    // ==========================================
    // SEARCH / FILTER
    // ==========================================

    public void filter(String text) {

        filteredClients.clear();

        if (text == null || text.trim().isEmpty()) {

            filteredClients.addAll(allClients);

        } else {

            String search = text.toLowerCase().trim();

            for (ClientModel client : allClients) {

                if (
                        client.name.toLowerCase().contains(search)
                                ||
                                client.company.toLowerCase().contains(search)
                                ||
                                client.email.toLowerCase().contains(search)
                ) {

                    filteredClients.add(client);
                }
            }
        }

        notifyDataSetChanged();
    }


    // ==========================================
    // CREATE VIEW HOLDER
    // ==========================================

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(
                        R.layout.client_card,
                        parent,
                        false
                );

        return new ViewHolder(view);
    }


    // ==========================================
    // DISPLAY CLIENT
    // ==========================================

    @Override
    public void onBindViewHolder(
            @NonNull ViewHolder holder,
            int position) {

        ClientModel client =
                filteredClients.get(position);

        holder.name.setText(client.name);

        holder.company.setText(client.company);

        holder.email.setText(
                "✉  " + client.email
        );

        holder.phone.setText(
                "☎  " + client.phone
        );

        holder.country.setText(
                "🌐  " + client.country
        );


        // CLIENT PHOTO

        if (client.photoUrl != null &&
                !client.photoUrl.isEmpty()) {

            loadImage(
                    client.photoUrl,
                    holder.photo
            );

        } else {

            holder.photo.setImageResource(
                    R.drawable.profile_placeholder
            );
        }


        // ==========================================
        // OPEN CLIENT DETAILS
        // ==========================================

        holder.itemView.setOnClickListener(v -> {

            Intent intent = new Intent(
                    v.getContext(),
                    ClientDetailsActivity.class
            );
            intent.putExtra("clientId", client.id);
            intent.putExtra("name", client.name);
            intent.putExtra("email", client.email);
            intent.putExtra("phone", client.phone);
            intent.putExtra("country", client.country);
            intent.putExtra("company", client.company);
            intent.putExtra("photoUrl", client.photoUrl);

            v.getContext().startActivity(intent);
        });
        holder.itemView.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            v.getContext(),
                            ClientDetailsActivity.class
                    );

            intent.putExtra(
                    "clientId",
                    client.id
            );

            intent.putExtra(
                    "name",
                    client.name
            );

            intent.putExtra(
                    "email",
                    client.email
            );

            intent.putExtra(
                    "phone",
                    client.phone
            );

            intent.putExtra(
                    "country",
                    client.country
            );

            intent.putExtra(
                    "company",
                    client.company
            );

            intent.putExtra(
                    "photoUrl",
                    client.photoUrl
            );

            v.getContext().startActivity(intent);
        });
    }


    // ==========================================
    // LOAD PHOTO
    // ==========================================

    private void loadImage(
            String url,
            ImageView imageView) {

        new Thread(() -> {

            try {

                java.net.URL imageUrl =
                        new java.net.URL(url);

                java.net.HttpURLConnection connection =
                        (java.net.HttpURLConnection)
                                imageUrl.openConnection();

                connection.connect();

                java.io.InputStream input =
                        connection.getInputStream();

                android.graphics.Bitmap bitmap =
                        android.graphics.BitmapFactory
                                .decodeStream(input);

                imageView.post(() ->
                        imageView.setImageBitmap(bitmap)
                );

                input.close();

                connection.disconnect();

            } catch (Exception ignored) {
                // Keep placeholder if image fails
            }

        }).start();
    }


    // ==========================================
    // ITEM COUNT
    // ==========================================

    @Override
    public int getItemCount() {

        return filteredClients.size();
    }


    // ==========================================
    // VIEW HOLDER
    // IMPORTANT:
    // DO NOT MAKE THIS PRIVATE
    // ==========================================

    public static class ViewHolder
            extends RecyclerView.ViewHolder {

        ImageView photo;

        TextView name;
        TextView company;
        TextView email;
        TextView phone;
        TextView country;


        public ViewHolder(@NonNull View itemView) {

            super(itemView);

            photo = itemView.findViewById(
                    R.id.clientPhoto
            );

            name = itemView.findViewById(
                    R.id.clientName
            );

            company = itemView.findViewById(
                    R.id.clientCompany
            );

            email = itemView.findViewById(
                    R.id.clientEmail
            );

            phone = itemView.findViewById(
                    R.id.clientPhone
            );

            country = itemView.findViewById(
                    R.id.clientCountry
            );
        }
    }
}