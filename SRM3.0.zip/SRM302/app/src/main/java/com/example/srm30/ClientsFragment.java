package com.example.srm30;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ClientsFragment extends Fragment {

    private static final int PICK_CLIENT_IMAGE = 501;

    private FirebaseFirestore db;
    private StorageReference storage;

    private RecyclerView recyclerView;
    private ClientAdapter adapter;

    private Uri selectedImageUri;

    // Keep reference to currently open dialog
    private Dialog currentDialog;

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable android.view.ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(
                R.layout.fragment_clients,
                container,
                false
        );

        db = FirebaseFirestore.getInstance();

        storage = FirebaseStorage
                .getInstance()
                .getReference();

        recyclerView = view.findViewById(
                R.id.clientRecyclerView
        );

        recyclerView.setLayoutManager(
                new LinearLayoutManager(requireContext())
        );

        adapter = new ClientAdapter();

        recyclerView.setAdapter(adapter);

        Button addButton = view.findViewById(
                R.id.addClientButton
        );

        if (addButton != null) {

            addButton.setOnClickListener(
                    v -> showAddClientDialog()
            );
        }

        EditText search = view.findViewById(
                R.id.searchClients
        );

        if (search != null) {

            search.addTextChangedListener(
                    new android.text.TextWatcher() {

                        @Override
                        public void beforeTextChanged(
                                CharSequence s,
                                int start,
                                int count,
                                int after) {
                        }

                        @Override
                        public void onTextChanged(
                                CharSequence s,
                                int start,
                                int before,
                                int count) {

                            adapter.filter(
                                    s.toString()
                            );
                        }

                        @Override
                        public void afterTextChanged(
                                android.text.Editable s) {
                        }
                    }
            );
        }

        loadClients();

        return view;
    }


    // ==========================================
    // LOAD CLIENTS
    // ==========================================

    private void loadClients() {

        db.collection("clients")
                .orderBy(
                        "createdAt",
                        Query.Direction.DESCENDING
                )
                .addSnapshotListener(
                        (snapshot, error) -> {

                            if (error != null) {

                                return;
                            }

                            if (snapshot == null) {

                                return;
                            }

                            ArrayList<ClientModel> clients =
                                    new ArrayList<>();

                            for (
                                    com.google.firebase.firestore.DocumentSnapshot doc
                                    : snapshot.getDocuments()) {

                                ClientModel client =
                                        new ClientModel();
                                client.id =
                                        doc.getId();

                                client.name =
                                        doc.getString("name");

                                client.email =
                                        doc.getString("email");

                                client.phone =
                                        doc.getString("phone");

                                client.country =
                                        doc.getString("country");

                                client.company =
                                        doc.getString("company");

                                client.photoUrl =
                                        doc.getString("photoUrl");

                                clients.add(client);
                            }

                            adapter.setClients(clients);
                        }
                );
    }


    // ==========================================
    // ADD CLIENT DIALOG
    // ==========================================

    private void showAddClientDialog() {

        selectedImageUri = null;

        Dialog dialog = new Dialog(
                requireContext()
        );

        currentDialog = dialog;

        dialog.setContentView(
                R.layout.item_add_client
        );

        if (dialog.getWindow() != null) {

            dialog.getWindow()
                    .setBackgroundDrawableResource(
                            android.R.color.transparent
                    );
        }


        // ==========================================
        // GET VIEWS
        // ==========================================

        ImageView photo = dialog.findViewById(
                R.id.newClientPhoto
        );

        ImageButton choosePhoto =
                dialog.findViewById(
                        R.id.selectClientPhoto
                );

        EditText name =
                dialog.findViewById(
                        R.id.clientNameInput
                );

        EditText email =
                dialog.findViewById(
                        R.id.clientEmailInput
                );

        EditText phone =
                dialog.findViewById(
                        R.id.clientPhoneInput
                );

        EditText country =
                dialog.findViewById(
                        R.id.clientCountryInput
                );

        EditText company =
                dialog.findViewById(
                        R.id.clientCompanyInput
                );
        EditText website =
                dialog.findViewById(
                        R.id.clientWebsiteInput
                );

        Button cancel =
                dialog.findViewById(
                        R.id.cancelClientButton
                );

        Button save =
                dialog.findViewById(
                        R.id.saveClientButton
                );


        // ==========================================
        // PHOTO BUTTON
        // ==========================================

        if (choosePhoto != null) {

            choosePhoto.setOnClickListener(v -> {

                Intent intent = new Intent(
                        Intent.ACTION_PICK,
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                );

                startActivityForResult(
                        intent,
                        PICK_CLIENT_IMAGE
                );
            });
        }


        // ==========================================
        // CANCEL
        // ==========================================

        if (cancel != null) {

            cancel.setOnClickListener(
                    v -> dialog.dismiss()
            );
        }


        // ==========================================
        // SAVE
        // ==========================================

        if (save != null) {

            save.setOnClickListener(v -> {

                String clientName =
                        name.getText()
                                .toString()
                                .trim();

                String clientEmail =
                        email.getText()
                                .toString()
                                .trim();

                String clientPhone =
                        phone.getText()
                                .toString()
                                .trim();

                String clientCountry =
                        country.getText()
                                .toString()
                                .trim();

                String clientCompany =
                        company.getText()
                                .toString()
                                .trim();
                String clientWebsite =
                        website.getText()
                                .toString()
                                .trim();


                if (clientName.isEmpty()) {

                    name.setError(
                            "Enter client name"
                    );

                    return;
                }


                if (clientEmail.isEmpty()) {

                    email.setError(
                            "Enter email"
                    );

                    return;
                }


                Map<String, Object> data =
                        new HashMap<>();

                data.put(
                        "name",
                        clientName
                );

                data.put(
                        "email",
                        clientEmail
                );

                data.put(
                        "phone",
                        clientPhone
                );

                data.put(
                        "country",
                        clientCountry
                );

                data.put(
                        "company",
                        clientCompany
                );

                data.put(
                        "website",
                        clientWebsite
                );

                data.put(
                        "createdAt",
                        com.google.firebase.firestore
                                .FieldValue
                                .serverTimestamp()
                );


                save.setEnabled(false);


                // ==================================
                // NO PHOTO
                // ==================================

                if (selectedImageUri == null) {

                    data.put(
                            "photoUrl",
                            ""
                    );

                    saveClient(
                            data,
                            dialog
                    );

                }

                // ==================================
                // WITH PHOTO
                // ==================================

                else {

                    uploadClientPhoto(
                            selectedImageUri,
                            data,
                            dialog
                    );
                }

            });
        }


        // ==========================================
        // SHOW DIALOG
        // ==========================================

        dialog.show();

        if (dialog.getWindow() != null) {

            dialog.getWindow()
                    .setLayout(
                            (int) (
                                    getResources()
                                            .getDisplayMetrics()
                                            .widthPixels
                                            * 0.92
                            ),
                            android.view.WindowManager
                                    .LayoutParams.WRAP_CONTENT
                    );
        }
    }


    // ==========================================
    // IMAGE RESULT
    // ==========================================

    @Override
    public void onActivityResult(
            int requestCode,
            int resultCode,
            @Nullable Intent data) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (
                requestCode == PICK_CLIENT_IMAGE &&
                        resultCode == Activity.RESULT_OK &&
                        data != null &&
                        data.getData() != null
        ) {

            selectedImageUri =
                    data.getData();

            // Show selected image immediately
            if (currentDialog != null) {

                ImageView photo =
                        currentDialog.findViewById(
                                R.id.newClientPhoto
                        );

                if (photo != null) {

                    photo.setImageURI(
                            selectedImageUri
                    );
                }
            }

            Toast.makeText(
                    requireContext(),
                    "Client photo selected",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // ==========================================
    // UPLOAD PHOTO
    // ==========================================

    private void uploadClientPhoto(
            Uri imageUri,
            Map<String, Object> data,
            Dialog dialog) {

        String fileName =
                "client_" +
                        System.currentTimeMillis() +
                        ".jpg";

        StorageReference imageRef =
                storage
                        .child("client_photos")
                        .child(fileName);


        imageRef.putFile(imageUri)

                .addOnSuccessListener(
                        taskSnapshot ->

                                imageRef
                                        .getDownloadUrl()

                                        .addOnSuccessListener(
                                                uri -> {

                                                    data.put(
                                                            "photoUrl",
                                                            uri.toString()
                                                    );

                                                    saveClient(
                                                            data,
                                                            dialog
                                                    );
                                                }
                                        )

                                        .addOnFailureListener(
                                                e -> {

                                                    Toast.makeText(
                                                            requireContext(),
                                                            "Could not get photo URL",
                                                            Toast.LENGTH_LONG
                                                    ).show();
                                                }
                                        )
                )

                .addOnFailureListener(
                        e -> {

                            Toast.makeText(
                                    requireContext(),
                                    "Photo upload failed: "
                                            + e.getMessage(),
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                );
    }


    // ==========================================
    // SAVE CLIENT
    // ==========================================

    private void saveClient(
            Map<String, Object> data,
            Dialog dialog) {

        db.collection("clients")
                .add(data)

                .addOnSuccessListener(
                        documentReference -> {

                            Toast.makeText(
                                    requireContext(),
                                    "Client added successfully",
                                    Toast.LENGTH_SHORT
                            ).show();

                            dialog.dismiss();
                        }
                )

                .addOnFailureListener(
                        e -> {

                            Toast.makeText(
                                    requireContext(),
                                    "Failed to add client: "
                                            + e.getMessage(),
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                );
    }
}